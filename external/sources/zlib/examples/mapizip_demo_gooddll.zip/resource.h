//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Scribble.rc
//
#define IDR_SCRIBBTYPE_SRVR_IP          4
#define IDR_SCRIBBTYPE_SRVR_EMB         5
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_SCRIBBTYPE                  129
#define IDD_PEN_WIDTHS                  131
#define IDC_THIN_PEN_WIDTH              1000
#define IDC_THICK_PEN_WIDTH             1001
#define IDC_DEFAULT_PEN_WIDTHS          1002
#define ID_PEN_THICK_OR_THIN            32772
#define ID_PEN_WIDTHS                   32773
#define ID_CANCEL_EDIT_SRVR             32774
#define ID_FILE_SEND_ZIPPED_MAIL        32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
